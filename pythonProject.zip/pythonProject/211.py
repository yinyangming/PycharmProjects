import time
import datetime
from multiping import MultiPing
import pymysql
from tkinter import *
from tkinter.ttk import *


class fond:
    def __int__(self):
        self.responses, self.no_responses ,self.host= []
        self.tag = True

    #链接数据库
    def get_conn(self):
        conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='111111', db='find_ip')  # db:表示数据库名称
        return conn


    #数据库查询  无参数select
    def query(self, sql):
        hostip =[]
        conn = fond.get_conn(self)
        cur = conn.cursor()
        cur.execute(sql)
        results = cur.fetchall()
        for row in results:
            id = row[0]
            hostip.append(id)
            pass
        conn.commit()
        cur.close()
        conn.close()
        return hostip

    #数据库查询  有参数select
    def query1(self, sql,args):
        conn = fond.get_conn(self)
        cur = conn.cursor()
        cur.execute(sql,args)
        results = cur.fetchall()
        return results
        conn.commit()
        cur.close()
        conn.close()

    #ping 命令函数
    def ping(self):
        a  =fond
        mp = MultiPing(a.query(self,"select ip from ip_list"))
        mp.send()
        self.responses, self.no_responses = mp.receive(1)
        self.dontLine()


    #查询不通IP地址信息
    def dontLine(self):
        current_datetime = datetime.datetime.now()
        formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
        findre = []
        i=0
        a = fond
        sql = "select ip,number from ip_list WHERE ip = %s"
        for row in self.no_responses:
            findre.append(a.query1(self,sql,row))
        for row  in findre:
            print(row[0][0])
            print(row[0][1])
            self.TreeViewtree.insert("",i,values=[row[0][0],row[0][1],"掉线",formatted_datetime])
            i+=1

    def Frame1(self):
        root = Tk()
        root.title("TreeView模块")
        root.geometry("660x335")

        # self.add_button = Button(root,command=self.change_button_text)
        self.add_button = Button(root,command = self.ping)
        self.add_button.place(x=50,y=50,width=100,height=50)
        self.add_button.pack()
        self.add_button.config(text = "Start" )


        # frame容器放置表格
        frame01 = Frame(root)
        frame01.place(x = 100,y = 100,width =420,height = 220 )
        # 加载滚动条
        scrollBar = Scrollbar(frame01)
        scrollBar.pack(side = RIGHT,fill = Y)
        # 准备表格
        self.TreeViewtree = Treeview(frame01,columns = ("IP","电话","状态","日期"),show = "headings",yscrollcommand = scrollBar.set)
        # 设置每一列的宽度和对齐方式
        self.TreeViewtree.column("IP",width = 80,anchor = "center")
        self.TreeViewtree.column("电话",width = 80,anchor = "center")
        self.TreeViewtree.column("状态",width = 60,anchor = "center")
        self.TreeViewtree.column("日期",width = 160,anchor = "center")
        # 设置表头的标题文本
        self.TreeViewtree.heading("IP",text = "IP")
        self.TreeViewtree.heading("电话",text = "电话")
        self.TreeViewtree.heading("状态",text = "状态")
        self.TreeViewtree.heading("日期",text = "日期")
        # 设置关联
        scrollBar.config(command = self.TreeViewtree.yview)
        # 加载表格信息
        self.TreeViewtree.pack()

        root.mainloop()

    # def change_button_text(self):
    #   if self.add_button["text"] == "Start":
    #         self.add_button.config(text="Stop")
    #         while self.add_button["text"] == "Stop":
    #             time.sleep(10000)
    #             self.ping()
    #
    #         print(self.no_responses)
    #     else:
    #         self.add_button.config(text="Start")




if __name__ == '__main__':
    a = fond()
    a.Frame1()



    # x = 0
    # while x == 0:
    #     a = fond()
    #     a.ping()
    #     a.dontLine()


