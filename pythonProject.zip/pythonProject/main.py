# This is a sample Python script.
from multiping import MultiPing
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # Create a MultiPing object to test three hosts / addresses
    mp = MultiPing(["8.8.8.8", "youtube.com", "127.0.0.1","180.101.50.24"])

    # Send the pings to those addresses
    mp.send()

    # With a 1 second timout, wait for responses (may return sooner if all
    # results are received).
    responses, no_responses = mp.receive(1)
    print(responses,no_responses)
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
