from multiping import MultiPing
mp = MultiPing(["110.242.68.66"])
mp.send()
responses, no_responses = mp.receive(1)
print(responses,no_responses)