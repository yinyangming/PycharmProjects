import tkinter as tk
from tkinter import ttk

def add_row():
    # 获取输入的数据
    data1 = entry1.get()
    data2 = entry2.get()
    data3 = entry3.get()

    # 添加新行到表格
    item_id = table.insert("", tk.END, values=(data1, data2, data3))
    # item_id = table.insert("", tk.END,  values=(data1, data2, data3))
    table.set(item_id, "text", "")

    # 清空输入框
    entry1.delete(0, tk.END)
    entry2.delete(0, tk.END)
    entry3.delete(0, tk.END)

# 创建窗口
window = tk.Tk()

# 创建输入框和添加按钮
entry1 = tk.Entry(window)
entry1.pack()
entry2 = tk.Entry(window)
entry2.pack()
entry3 = tk.Entry(window)
entry3.pack()
add_button = tk.Button(window, text="添加行", command=add_row)
add_button.pack()

# 创建表格
table = ttk.Treeview(window)
table["columns"] = ("Column 1", "Column 2", "Column 3")
table.heading("Column 1", text="Column 1")
table.heading("Column 2", text="Column 2")
table.heading("Column 3", text="Column 3")

# 设置每列的格式
table.column("Column 1", width=100, anchor="center")
table.column("Column 2", width=150, anchor="w")
table.column("Column 3", width=200, anchor="e")
# table.column("text", width=0, stretch=tk.NO)

table.pack()

# 运行窗口的主事件循环
window.mainloop()
